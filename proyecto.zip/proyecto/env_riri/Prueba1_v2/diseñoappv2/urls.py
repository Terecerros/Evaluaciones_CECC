from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views #vistas por defecto en django
from . import views



urlpatterns = [
    
    #LOGIN
    path('', views.index, name= 'index'),
    path('login/', views.login_view, name='login_view'),
    path('logout/', views.logout_view, name='logout'),
    path('login_ev/', views.login_ev, name='login_ev'),
    path('adminpage/', views.admin, name='adminpage'),
    path('evaluadorpage/', views.evaluador, name='evaluadorpage'),
    
    #ADMINISTRADOR
    path('register/', views.register, name='register'), #REG DE EVALUADOR

    #REGISTRAR COMO ADMINISTRADOR   
    path('registroadmin/', views.registroadmin, name='registroadmin'), #REGISTRO PSICO    
    path('lista_poliadmin/', views.lista_poliadmin, name="lista_poliadmin"), #LISTA POLIGRAFICA    
    path('reg_poliadmin/<int:id>/', views.reg_poliadmin, name='reg_poliadmin'),  #REG POLIGRAFICO 

    #VALIDACIONES
    path('validaradmin/', views.validaradmin, name="validaradmin"),
    path('editaradmin/<int:id>/', views.editaradmin, name="editaradmin"), #REG VALIDACION
    path('editaradmin2/<int:id>/', views.editaradmin2, name="editaradmin2"), #REG VALIDACION
    path('ver1/<int:id>/', views.ver1, name="ver1"), #VER PDF
    path('consulta/', views.consulta, name="consulta"), #CHECA DIPONIBILIDAD EN 4 FECHAS DIFERENTES
    path('consulta2/', views.consulta2, name="consulta2"), #CHECA DIPONIBILIDAD EN 6 SELECT DIFERENTES

    #REPROGRAMACIONES
    path('repropsicoadmin/', views.repropsicoadmin, name="repropsicoadmin"), #LISTA DE REPRO PSICO
    path('reg_repsicoadmin/<int:id>/', views.reg_repsicoadmin, name="reg_repsicoadmin"), #REPRO REG PSICO
    path('repropoliadmin/', views.repropoliadmin, name="repropoliadmin"), #LISTA DE REPRO POLI
    path('reg_repoliadmin/<int:id>/', views.reg_repoliadmin, name="reg_repoliadmin"), #REPRO REG POLI
 
    #NO RECOMENDABLES
    path('norecadmin/', views.norecadmin, name="norecadmin"), #NO RECOMENDABLES
    path('regnorecadmin/<int:id>/', views.regnorecadmin, name="regnorecadmin"), #REG NO REC
   
    #HISTORIAL
    path('consulta_admin/', views.consulta_admin, name="consulta_admin"),
   
    #REPORTES 
    path('reporte/', views.reporte, name='reporte'),
    
    #ELIMINAR EVALUADORES
    path('delete_ev/', views.delete_ev, name="delete_ev"),
    path('eliminar2/<int:id>/', views.eliminar2, name="eliminar2"),

    #ELIMINAR REGISTROS
    path('lista_delete1/', views.lista_delete1, name="lista_delete1"),
    path('eliminar1/<int:id>/', views.eliminar1, name="eliminar1"),
    
    ###########################*********************************************

    #EVALUACIONES
   
    #VALIDAR
    path('validar/', views.validar, name="validar"),
    path('editar/<int:id>/', views.editar, name="editar"), #REG VALIDACION
    path('editar2/<int:id>/', views.editar2, name="editar2"), #REG VALIDACION
    path('ver/<int:id>/', views.ver, name="ver"), #VER PDF

    #REGISTROS
    path('registro/', views.registro, name='registro'), #REGISTRO PSICO    
    path('lista_poli/', views.lista_poli, name="lista_poli"), #LISTA POLIGRAFICA    
    path('reg_poli/<int:id>/', views.reg_poli, name='reg_poli'),  #REG POLIGRAFICO 

    #REPROGRAMACIONES
    path('repropsico/', views.repropsico, name="repropsico"), #LISTA DE REPRO PSICO
    path('reg_repsico/<int:id>/', views.reg_repsico, name="reg_repsico"), #REPRO REG PSICO
    
    path('repropoli/', views.repropoli, name="repropoli"), #LISTA DE REPRO POLI
    path('reg_repoli/<int:id>/', views.reg_repoli, name="reg_repoli"), #REPRO REG POLI
    
    #NO RECOMENDABLES
    path('norec/', views.norec, name="norec"), #NO RECOMENDABLES
    path('regpsico_norec/<int:id>/', views.regpsico_norec, name="regpsico_norec"), #REG NO REC
    
    #HISTORIAL
    path('lista/', views.lista, name="lista"),
    
    #ELIMINAR REGISTROS
    path('lista_delete/', views.lista_delete, name="lista_delete"),
    path('eliminar/<int:id>/', views.eliminar, name="eliminar"),
    
    
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)















