from django.db import models
from django.contrib.auth.models import AbstractUser
    
class User(AbstractUser):
    is_admin= models.BooleanField('Is admin', default=False)
    is_evaluador = models.BooleanField('Is evaluador', default=False)

# Create your models here.
class Registro(models.Model):
    # Campos de texto
    ficha = models.CharField(max_length=10)
    nombre = models.CharField(max_length=500)
    curp = models.CharField(max_length=18)

    #Campos con opciones
    cd_op = [
        ('AGUASCALIENTES','AGUASCALIENTES'),
        ('BAJA CALIFORNIA', 'BAJA CALIFORNIA'),
        ('BAJA CALIFORNIA SUR', 'BAJA CALIFORNIA SUR'),
        ('CAMPECHE', 'CAMPECHE'),
        ('COAHUILA DE ZARAGOZA', 'COAHUILA DE ZARAGOZA'),
        ('COLIMA', 'COLIMA'),
        ('CHIAPAS', 'CHIAPAS'),
        ('CHIHUAHUA', 'CHIHUAHUA'),
        ('CIUDAD DE MEXICO', 'CIUDAD DE MEXICO'),
        ('DURANGO', 'DURANGO'),
        ('GUANAJUATO', 'GUANAJUATO'),
        ('GUERRERO', 'GUERRERO'),
        ('HIDALGO', 'HIDALGO'),
        ('JALISCO', 'JALISCO'),
        ('MEXICO', 'MEXICO'),
        ('MICHOACAN DE OCAMPO', 'MICHOACAN DE OCAMPO'),
        ('MORELOS', 'MORELOS'),
        ('NAYARIT', 'NAYARIT'),
        ('NUEVO LEON', 'NUEVO LEON'),
        ('OAXACA', 'OAXACA'),
        ('PUEBLA', 'PUEBLA'),
        ('QUERETARO', 'QUERETARO'),
        ('QUINTANA ROO', 'QUINTANA ROO'),
        ('SAN LUIS POTOSI', 'SAN LUIS POTOSI'),
        ('SINALOA', 'SINALOA'),
        ('SONORA', 'SONORA'),
        ('TABASCO', 'TABASCO'),
        ('TAMAULIPAS', 'TAMAULIPAS'),
        ('TLAXCALA', 'TLAXCALA'),
        ('VERACRUZ', 'VERACRUZ'),
        ('YUCATAN', 'YUCATAN'),
        ('ZACATECAS', 'ZACATECAS'),
    ]
    ciudad = models.CharField(max_length=100, choices=cd_op, blank=True, null=True, default='')
    
    mot_op = [
        ('NUEVO INGRESO','NUEVO INGRESO'),
        ('PERMANENCIA','PERMANENCIA'),
    ]
    motivo = models.CharField(max_length=100, choices=mot_op,null=True, blank=True, default='')

    area_op = [
        ('SSE','SSE'),
        ('SCH','SCH'),
    ]
    area = models.CharField(max_length=100, choices=area_op,null=True, blank=True, default='')
           
    date1 = models.DateField(null=True, blank=True)
    
    hrc_op = [
        ('9:00 am','9:00 am'),
        ('11:00 am','11:00 am'),
        ('16:00 pm','16:00 pm'),
    ]
    hrc = models.CharField(max_length=100, choices=hrc_op, null=True, blank=True, default='')
    
    hrb_op = [
        ('9:00 am','9:00 am'),
        ('10:00 am','10:00 am'),
        ('11:00 am','11:00 am'),
        ('12:00 pm','12:00 pm'),
    ]
    hrb = models.CharField(max_length=100, choices=hrb_op, null=True,blank=True, default='')
     
    date2 = models.DateField(null=True, blank=True)
     
    hrpoli_op = [
        ('8:30 am','8:30 am'),
        ('11:00 am','11:00 am'),
    ]
    hrpoli = models.CharField(max_length=100, choices=hrpoli_op, null=True, blank=True, default='')
  
    file = models.FileField(upload_to='documents/')

    status_op= [
        ('RECOMENDABLE','RECOMENDABLE'),
        ('NO RECOMENDABLE','NO RECOMENDABLE'),
        ('REPROGRAMACION PSICOLOGICA','REPROGRAMACION PSICOLOGICA'),
        ('REPROGRAMACION POLIGRAFICA','REPROGRAMACION POLIGRAFICA'),
        ('REEXAMINACION','REEXAMINACION'),
    ]
    status = models.CharField(max_length=100, choices=status_op, blank=True, null=True, default='')

    tipo2_op= [
        ('RECOMENDABLE','RECOMENDABLE'),
        ('NO RECOMENDABLE','NO RECOMENDABLE'),
        ('REPROGRAMACION PSICOLOGICA','REPROGRAMACION PSICOLOGICA'),
        ('REPROGRAMACION POLIGRAFICA','REPROGRAMACION POLIGRAFICA'),
        ('EVALUACION PSICOLOGICA','EVALUACION PSICOLOGICA'),
        ('EVALUACION POLIGRAFICA','EVALUACION POLIGRAFICA'),
        ('REEXAMINACION','REEXAMINACION'),
    ]
    tipo2 = models.CharField(max_length=100, choices=status_op, blank=True, null=True, default='')

    status2_op= [
        ('RECOMENDABLE','RECOMENDABLE'),
        ('NO RECOMENDABLE','NO RECOMENDABLE'),
        ('REPROGRAMACION PSICOLOGICA','REPROGRAMACION PSICOLOGICA'),
        ('REPROGRAMACION POLIGRAFICA','REPROGRAMACION POLIGRAFICA'),
        ('REEXAMINACION','REEXAMINACION'),
    ]
    status2 = models.CharField(max_length=100, choices=status_op, blank=True, null=True, default='')
    
    daterep3 = models.DateField(null=True, blank=True)
    
    hrcrep_op = [
        ('9:00 am','9:00 am'),
        ('11:00 am','11:00 am'),
        ('16:00 pm','16:00 pm'),
    ]
    hrcrep = models.CharField(max_length=100, choices=hrcrep_op, null=True, blank=True, default='')
    
    hrbrep_op = [
        ('9:00 am','9:00 am'),
        ('10:00 am','10:00 am'),
        ('11:00 am','11:00 am'),
        ('12:00 pm','12:00 pm'),
    ]
    hrbrep = models.CharField(max_length=100, choices=hrbrep_op, null=True,blank=True, default='')
    
    daterep4 = models.DateField(null=True, blank=True)
     
    hrpolirep_op = [
        ('8:30 am','8:30 am'),
        ('11:00 am','11:00 am'),
    ]
    hrpolirep = models.CharField(max_length=100, choices=hrpolirep_op, null=True, blank=True, default='')

    tipopsico_op= [
        ('EVALUACION PSICOLOGICA','EVALUACION PSICOLOGICA'),
    ]
    tipopsico = models.CharField(max_length=100, choices=tipopsico_op, blank=True, null=True, default='')
    
    tipoli_op= [
        ('EVALUACION POLIGRAFICA','EVALUACION POLIGRAFICA'),
    ]
    tipoli = models.CharField(max_length=100, choices=tipoli_op, blank=True, null=True, default='')
    
    programado_op= [
        ('PROGRAMADO','PROGRAMADO'),
    ]
    programado = models.CharField(max_length=100, choices=programado_op, blank=True, null=True, default='')
    
    def save(self, *args, **kwargs):
        # Convierte los campos relevantes a mayúsculas antes de guardar
        self.ficha = self.ficha.upper()
        self.nombre = self.nombre.upper()
        self.curp = self.curp.upper()
        self.ciudad = self.ciudad.upper()
        self.motivo = self.motivo.upper()
        self.area = self.area.upper()

        super().save(*args, **kwargs)