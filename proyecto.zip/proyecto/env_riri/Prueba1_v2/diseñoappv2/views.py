from django.shortcuts import render, redirect, get_object_or_404
from .forms import SignUpForm, LoginForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from . models import Registro, User
from . forms import RegistroModelForm


def index(request):
    return render(request, 'index.html')

def login_view(request): #LOGIN ADMIN
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_admin:
                login(request, user)
                return redirect('adminpage')
            elif user is not None and user.is_evaluador:
                login(request, user)
                return redirect('evaluador')
            else:
                msg= 'Usuario o contraseña incorrecta,inténtalo de nuevo.'
        else:
            msg = 'error validating form'
    return render(request, 'login/login_admin.html', {'form': form, 'msg': msg})

def logout_view(request): #LOGOUT
    logout(request)
    return redirect('index')  

#LOGIN EVALUADOR
def login_ev(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_evaluador:
                login(request, user)
                return redirect('evaluadorpage')
            else:
                msg= 'Usuario o contraseña incorrecta,inténtalo de nuevo.'
        else:
            msg = 'error validating form'
    return render(request, 'login/login_ev.html', {'form': form, 'msg': msg})


####### ADMINISTRADOR #######################
@login_required
def admin(request):
    user = request.user
    return render(request,'admin/home_admin.html',{'user':user})

@login_required
def register(request): #REGISTRO DE EVALUADORES 
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
           user = form.save()
           return redirect('register')
    else:
        form = SignUpForm()
    return render(request,'admin/register_eva.html', {'form': form})

#REGISTROS PSICOLOGICOS
@login_required
def registroadmin(request):
   form = RegistroModelForm()   
   if request.method == 'POST':
        form = RegistroModelForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('registroadmin')  
   else:
        form = RegistroModelForm()
        print(form.errors)
   return render(request, 'admin/regis_admin.html',{'form':form})

#LISTA DE VALIDAR REGISTROS
@login_required
def validaradmin(request):
    reg = Registro.objects.all()
    return render(request, 'admin/validacion_admin.html', {'reg': reg})   

#VALIDACIONES DE REGISTROS FORM
@login_required
def editaradmin(request,id): #VAL
    reg = Registro.objects.get(id=id)

    ficha = request.POST.get('ficha')
    nombre = request.POST.get('nombre')
    curp = request.POST.get('curp')
    status = request.POST.get('status')

    if request.method == 'POST':
        reg.status = status       
        reg.save()
        return redirect('validaradmin')
    else:
       form = RegistroModelForm()
       print(form.errors) 
    return render(request, 'admin/val_admin.html',{'reg':reg})

@login_required
def editaradmin2(request,id): #VAL
    reg = Registro.objects.get(id=id)

    ficha = request.POST.get('ficha')
    nombre = request.POST.get('nombre')
    curp = request.POST.get('curp')
    status2 = request.POST.get('status2')

    if request.method == 'POST':
        reg.status2 = status2       
        reg.save()
        return redirect('validar')
    else:
       form = RegistroModelForm()
       print(form.errors)
    
    return render(request, 'admin/val2_admin.html',{'reg':reg})

#LISTA DE REGISTROS POLI  
@login_required
def lista_poliadmin(request): 
    listapoli = Registro.objects.all() 
    return render(request,'admin/poli_listadmin.html',{'listapoli':listapoli})

#REGISTROS POLIGRAFICOS
@login_required
def reg_poliadmin(request,id): 
    reg = Registro.objects.get(id=id)

    if request.method == 'POST':
        # Obtén los datos del formulario
        ficha = request.POST['ficha']
        nombre = request.POST['nombre']
        curp = request.POST['curp']
        programado = request.POST['programado']
        date2 = request.POST['date2']
        hrpoli = request.POST['hrpoli']
        tipoli = request.POST['tipoli']

        # Actualiza el registro existente con el campo 'programado'
        reg.programado = programado
        reg.save()

        # Crea un nuevo registro con los demás campos
        nuevo_registro = Registro(
            ficha=ficha,
            nombre=nombre,
            curp=curp,
            date2=date2,
            hrpoli=hrpoli,
            tipoli=tipoli,
            programado=programado  # También puedes establecer 'programado' en el nuevo registro si es necesario
        )
        nuevo_registro.save()

        return redirect('lista_poliadmin')
    else:
        form = RegistroModelForm()
    return render(request, 'admin/regpoli_admin.html', {'form': form, 'reg': reg})

#LISTA DE REPROGRAMAR PSICO
@login_required
def repropsicoadmin(request): 
    repropsico = Registro.objects.all()  
    return render(request,'admin/repropsico_admin.html',{'repropsico':repropsico})

@login_required
def reg_repsicoadmin(request, id):
    reg = Registro.objects.get(id=id)
    if request.method == 'POST':
        form = RegistroModelForm(request.POST, instance=reg)

        if form.is_valid():
            form.save()
            return redirect('repropsicoadmin')
    else:
        form = RegistroModelForm(instance=reg)
    return render(request, 'admin/regrepsico_admin.html', {'form': form, 'reg': reg})

#LISTA DE REPROGRAMAR POLI
@login_required
def repropoliadmin(request): 
   repropoli = Registro.objects.all()
   return render(request,'admin/repropoli_admin.html',{'repropoli':repropoli})

#REPROGRAMACION DE REGISTOS POLIGRAFICOS
@login_required
def reg_repoliadmin(request, id):
    reg = Registro.objects.get(id=id)

    if request.method == 'POST':
        form = RegistroModelForm(request.POST, instance=reg)

        if form.is_valid():
            form.save()
            return redirect('repropoliadmin')
    else:
        form = RegistroModelForm(instance=reg)
    return render(request, 'admin/regrepoli_admin.html',{'form':form,'reg':reg})

#LISTA DE NO RECOMENDABLES
@login_required
def norecadmin(request): 
   noreclist = Registro.objects.all()
   return render(request,'admin/norec_admin.html',{'noreclist':noreclist })

#REGISTROS NO RECOMENDABLES
@login_required
def regnorecadmin(request, id):
    reg = Registro.objects.get(id=id)
    
    if request.method == 'POST':
        # Obtén los datos del formulario
        ficha = request.POST['ficha']
        nombre = request.POST['nombre']
        curp = request.POST['curp']
        programado = request.POST['programado']
        date1 = request.POST['date1']
        hrc = request.POST['hrc']
        hrb = request.POST['hrb']
        tipopsico = request.POST['tipopsico']
                       
        # Actualiza el registro existente con el campo 'programado'
        reg.programado = programado
        reg.save()

        # Crea un nuevo registro con los demás campos
        nuevo_registro = Registro(
        ficha=ficha,
        nombre=nombre,
        curp=curp,
        date1=date1,
        hrc=hrc,
        hrb=hrb,
        tipopsico=tipopsico,
        programado=programado,
        )
        nuevo_registro.save()
        return redirect('norec')
    
    else:
       form = RegistroModelForm()
       print(form.errors)
     
    return render(request, 'admin/regnorec_admin.html',{'form': form,'reg':reg})

#HISTORIAL
@login_required
def consulta_admin(request):
    lista = Registro.objects.all()
      #FILTRADO DE FECHAS
    fecha_filtro = request.GET.get('fecha_filtro', None)
    if fecha_filtro:
       lista = lista.filter(date1=fecha_filtro)

    contexto = {'lista':lista,'fecha_filtro': fecha_filtro}

    return render(request, 'admin/consulta.html',contexto)

#REPORTE
@login_required
def reporte(request):
   lista = Registro.objects.all()
   #FILTRADO DE FECHAS
   fecha_filtro = request.GET.get('fecha_filtro', None)
   if fecha_filtro:
       lista = lista.filter(date1=fecha_filtro)

   contexto = {'lista':lista,'fecha_filtro': fecha_filtro}

   return render(request,'admin/reporte.html',contexto)

#VER PDF
@login_required
def ver1(request,id):
  documento = Registro.objects.get(id=id)     
  return render(request, 'admin/ver_pdf1.html', {'documento': documento})

#ELIMINAR EVALUADOR
@login_required
def delete_ev(request): 
   list = User.objects.all()
   contexto = {'list':list}
   return render(request,'admin/delete_ev.html',contexto)


def eliminar2(request, id):
    eliminar = get_object_or_404(User,id = id)
    eliminar.delete()
    return redirect('delete_ev')

#LISTA DE ELIMINAR REGISTROS  
@login_required
def lista_delete1(request): 
   lista = Registro.objects.all()
   contexto = {'lista':lista}
   return render(request,'admin/delete.html',contexto)

def eliminar1(request, id):
    eliminar = get_object_or_404(Registro,id = id)
    eliminar.delete()
    return redirect('lista_delete1')


####################***************************************************************

############   EVALUADOR #############
@login_required
def evaluador(request):
    user = request.user
    return render(request,'evaluador/home.html',{'user':user})

#REGISTROS PSICOLOGICOS
@login_required
def registro(request):
   form = RegistroModelForm()
   
   if request.method == 'POST':
        form = RegistroModelForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('registro')  
   else:
        form = RegistroModelForm()
        print(form.errors)

   return render(request, 'evaluador/regis.html',{'form':form})

#LISTA DE VALIDAR REGISTROS DB'reg':reg
@login_required
def validar(request):
    reg = Registro.objects.all()
    return render(request, 'evaluador/validacion.html', {'reg': reg})   

#VER PDF
@login_required
def ver(request,id):
  documento = Registro.objects.get(id=id)     
  return render(request, 'evaluador/ver_pdf.html', {'documento': documento})

#VALIDACIONES DE REGISTROS FORM
@login_required
def editar(request,id): #VAL
    reg = Registro.objects.get(id=id)

    ficha = request.POST.get('ficha')
    nombre = request.POST.get('nombre')
    curp = request.POST.get('curp')
    status = request.POST.get('status')

    if request.method == 'POST':
        reg.status = status       
        reg.save()
        return redirect('validar')
    else:
       form = RegistroModelForm()
       print(form.errors)
    
    return render(request, 'evaluador/val.html',{'reg':reg})

@login_required
def editar2(request,id): #VAL
    reg = Registro.objects.get(id=id)

    ficha = request.POST.get('ficha')
    nombre = request.POST.get('nombre')
    curp = request.POST.get('curp')
    status2 = request.POST.get('status2')

    if request.method == 'POST':
        reg.status2 = status2       
        reg.save()
        return redirect('validar')
    else:
       form = RegistroModelForm()
       print(form.errors)
    
    return render(request, 'evaluador/val2.html',{'reg':reg})

#LISTA DE REGISTROS POLI  
@login_required
def lista_poli(request): 
    listapoli = Registro.objects.all() 
    return render(request,'evaluador/lista_poli.html',{'listapoli':listapoli})


#REGISTROS POLIGRAFICOS
@login_required
def reg_poli(request,id): 
    reg = Registro.objects.get(id=id)

    if request.method == 'POST':
        # Obtén los datos del formulario
        ficha = request.POST['ficha']
        nombre = request.POST['nombre']
        curp = request.POST['curp']
        programado = request.POST['programado']
        date2 = request.POST['date2']
        hrpoli = request.POST['hrpoli']
        tipoli = request.POST['tipoli']

        # Actualiza el registro existente con el campo 'programado'
        reg.programado = programado
        reg.save()

        # Crea un nuevo registro con los demás campos
        nuevo_registro = Registro(
            ficha=ficha,
            nombre=nombre,
            curp=curp,
            date2=date2,
            hrpoli=hrpoli,
            tipoli=tipoli,
            programado=programado  # También puedes establecer 'programado' en el nuevo registro si es necesario
       )
        nuevo_registro.save()

        return redirect('lista_poli')
    else:
        form = RegistroModelForm()
    return render(request, 'evaluador/regpoli.html', {'form': form, 'reg': reg})


#LISTA DE REPROGRAMAR PSICO
@login_required
def repropsico(request): 
   repropsico = Registro.objects.all()  
   return render(request,'evaluador/repropsico.html',{'repropsico':repropsico})

@login_required
def reg_repsico(request, id):
    reg = Registro.objects.get(id=id)
    if request.method == 'POST':
        form = RegistroModelForm(request.POST, instance=reg)

        if form.is_valid():
            form.save()
            return redirect('repropsico')
    else:
        form = RegistroModelForm(instance=reg)
    return render(request, 'evaluador/reg_repsico.html', {'form': form, 'reg': reg})

#LISTA DE REPROGRAMAR POLI
@login_required
def repropoli(request): 
   repropoli = Registro.objects.all()
   return render(request,'evaluador/repropoli.html',{'repropoli':repropoli})

#REPROGRAMACION DE REGISTOS POLIGRAFICOS
@login_required
def reg_repoli(request, id):
    reg = Registro.objects.get(id=id)

    if request.method == 'POST':
        form = RegistroModelForm(request.POST, instance=reg)
        if form.is_valid():
            form.save()
            return redirect('repropoli')
    else:
        form = RegistroModelForm(instance=reg)
    return render(request, 'evaluador/reg_repoli.html',{'form':form,'reg':reg})

#LISTA DE NO RECOMENDABLES
@login_required
def norec(request): 
   noreclist = Registro.objects.all()
   return render(request,'evaluador/norec.html',{'noreclist':noreclist })

#REGISTROS NO RECOMENDABLES
@login_required
def regpsico_norec(request, id):
    reg = Registro.objects.get(id=id)
   
    if request.method == 'POST':
        # Obtén los datos del formulario
        ficha = request.POST['ficha']
        nombre = request.POST['nombre']
        curp = request.POST['curp']
        programado = request.POST['programado']
        date1 = request.POST['date1']
        hrc = request.POST['hrc']
        hrb = request.POST['hrb']
        tipopsico = request.POST['tipopsico']
                       
        # Actualiza el registro existente con el campo 'programado'
        reg.programado = programado
        reg.save()

        # Crea un nuevo registro con los demás campos
        nuevo_registro = Registro(
        ficha=ficha,
        nombre=nombre,
        curp=curp,
        date1=date1,
        hrc=hrc,
        hrb=hrb,
        tipopsico=tipopsico,
        programado=programado,
        )
        nuevo_registro.save()
        return redirect('norec')
    
    else:
       form = RegistroModelForm()
       print(form.errors)
    
    return render(request, 'evaluador/reg_norecom.html',{'form': form,'reg':reg})

#LISTA DE ELIMINAR REGISTROS  
@login_required
def lista_delete(request): 
   lista = Registro.objects.all()
   contexto = {'lista':lista}
   return render(request,'evaluador/lista_eliminar.html',contexto)

def eliminar(request, id):
    eliminar = get_object_or_404(Registro,id = id)
    eliminar.delete()
    return redirect('lista_delete')

#HISTORIAL
@login_required
def lista(request):
    lista = Registro.objects.all()
    #FILTRADO DE FECHAS
    fecha_filtro = request.GET.get('fecha_filtro', None)
    if fecha_filtro:
       lista = lista.filter(date1=fecha_filtro)

    contexto = {'lista':lista,'fecha_filtro': fecha_filtro}

    return render(request, 'evaluador/lista.html', contexto)


#LOS DOS CASOS

def consulta(request):  #checa el cupo en 4 calendarios diferentes
    fecha_seleccionada = request.GET.get('fecha_seleccionada')

    ocupacion_date1 = Registro.objects.filter(date1=fecha_seleccionada).count()
    ocupacion_date2 = Registro.objects.filter(date2=fecha_seleccionada).count()
    ocupacion_daterep3 = Registro.objects.filter(daterep3=fecha_seleccionada).count()
    ocupacion_daterep4 = Registro.objects.filter(daterep4=fecha_seleccionada).count()

    return JsonResponse({
        'ocupacion_date1': ocupacion_date1,
        'ocupacion_date2': ocupacion_date2,
        'ocupacion_daterep3': ocupacion_daterep3,
        'ocupacion_daterep4': ocupacion_daterep4,
    })

#checa el cupo en 6 select y 4 calendarios diferentes
def consulta2(request): 
   # Recibe las opciones seleccionadas y la fecha
    hrc_hora = request.GET.get('hrc_hora')
    hrb_hora = request.GET.get('hrb_hora')
    hrpoli_hora = request.GET.get('hrpoli_hora')
    hrcrep_hora = request.GET.get('hrcrep_hora')
    hrbrep_hora = request.GET.get('hrbrep_hora')
    hrpolirep_hora = request.GET.get('hrpolirep_hora')

    fecha_seleccionada = request.GET.get('fecha_seleccionada')

    # Realiza la lógica para contar los registros en función de las opciones y la fecha seleccionada
    conteo_hrc = Registro.objects.filter(hrc=hrc_hora, date1=fecha_seleccionada).count()
    conteo_hrb = Registro.objects.filter(hrb=hrb_hora, date1=fecha_seleccionada).count()
    conteo_hrpoli = Registro.objects.filter(hrpoli=hrpoli_hora, date2=fecha_seleccionada).count()
    conteo_hrcrep = Registro.objects.filter(hrcrep=hrcrep_hora, daterep3=fecha_seleccionada).count()
    conteo_hrbrep = Registro.objects.filter(hrbrep=hrbrep_hora, daterep3=fecha_seleccionada).count()            
    conteo_hrpolirep = Registro.objects.filter(hrpolirep=hrpolirep_hora, daterep4=fecha_seleccionada).count()

    # Devuelve los resultados en formato JSON
    return JsonResponse({
        'conteo_hrc': conteo_hrc,
        'conteo_hrb': conteo_hrb,
        'conteo_hrpoli': conteo_hrpoli,
        'conteo_hrcrep': conteo_hrcrep,
        'conteo_hrbrep': conteo_hrbrep,
        'conteo_hrpolirep': conteo_hrpolirep,
    })
  
















